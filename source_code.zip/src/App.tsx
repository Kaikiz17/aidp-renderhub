import React, { useEffect, useState, useRef } from 'react';
import { client } from './utils/client';
import { Plus, Play, Download, FileUp, RefreshCw, CheckCircle, XCircle, Clock, Loader2 } from 'lucide-react';

// Types
interface Job {
  id: string;
  status: 'queued' | 'running' | 'completed' | 'failed' | 'ready';
  filename: string;
  frameStart: number;
  frameEnd: number;
  resolution: string;
  outputFormat: string;
  createdAt: number;
  updatedAt: number;
  costEstimate?: string;
  downloadUrl?: string;
}

function App() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const authContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    checkSession();
  }, []);

  async function checkSession() {
    const { data } = await client.auth.getSession();
    setUser(data?.user ?? null);
    setLoading(false);
  }

  useEffect(() => {
    if (!loading && !user && authContainerRef.current) {
      client.auth.renderAuthUI(authContainerRef.current, {
        onLogin: () => checkSession(),
      });
    }
  }, [loading, user]);

  if (loading) return <div className="flex items-center justify-center h-screen bg-gray-900 text-white">Loading...</div>;

  if (!user) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-900">
        <div ref={authContainerRef} className="w-full max-w-md p-6 bg-gray-800 rounded-xl shadow-xl" />
      </div>
    );
  }

  return <Dashboard user={user} onLogout={() => client.auth.signOut().then(() => setUser(null))} />;
}

function Dashboard({ user, onLogout }: { user: any, onLogout: () => void }) {
  const [view, setView] = useState<'list' | 'create'>('list');
  const [refreshKey, setRefreshKey] = useState(0);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans">
      <header className="border-b border-gray-800 bg-gray-900/50 backdrop-blur sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold">R</div>
            <h1 className="text-xl font-bold">AIDP RenderHub</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-400">{user.email}</span>
            <button onClick={onLogout} className="text-sm text-gray-400 hover:text-white">Sign Out</button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold">{view === 'list' ? 'Render Jobs' : 'New Render Job'}</h2>
          {view === 'list' ? (
            <button
              onClick={() => setView('create')}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg transition-colors"
            >
              <Plus size={18} /> New Job
            </button>
          ) : (
            <button
              onClick={() => setView('list')}
              className="text-gray-400 hover:text-white"
            >
              Cancel
            </button>
          )}
        </div>

        {view === 'list' ? (
          <JobList key={refreshKey} />
        ) : (
          <CreateJob onCreated={() => { setView('list'); setRefreshKey(k => k + 1); }} />
        )}
      </main>
    </div>
  );
}

function JobList() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchJobs();
    const interval = setInterval(fetchJobs, 5000); // Poll every 5s
    return () => clearInterval(interval);
  }, []);

  async function fetchJobs() {
    try {
      const res = await client.api.fetch('/api/jobs');
      const json = await res.json();
      if (json.data) setJobs(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  if (loading && jobs.length === 0) return <div className="text-center py-12 text-gray-500">Loading jobs...</div>;

  if (jobs.length === 0) {
    return (
      <div className="text-center py-12 bg-gray-800/50 rounded-xl border border-gray-800">
        <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-600">
          <FileUp size={32} />
        </div>
        <h3 className="text-lg font-medium text-white mb-2">No jobs yet</h3>
        <p className="text-gray-400">Upload a .blend file to start rendering.</p>
      </div>
    );
  }

  return (
    <div className="grid gap-4">
      {jobs.map(job => (
        <JobCard key={job.id} job={job} onUpdate={fetchJobs} />
      ))}
    </div>
  );
}

function JobCard({ job, onUpdate }: { job: Job, onUpdate: () => void }) {
  const [downloading, setDownloading] = useState(false);

  async function handleStart() {
    await client.api.fetch(`/api/jobs/${job.id}/start`, { method: 'POST' });
    onUpdate();
  }

  async function handleDownload() {
    setDownloading(true);
    try {
      const res = await client.api.fetch(`/api/jobs/${job.id}/download`);
      const json = await res.json();
      if (json.data?.url) {
        window.open(json.data.url, '_blank');
      } else {
        alert('Download not available');
      }
    } catch (e) {
      alert('Error getting download link');
    } finally {
      setDownloading(false);
    }
  }
  
  // Demo function to complete job
  async function handleComplete() {
     await client.api.fetch(`/api/jobs/${job.id}/complete`, { method: 'POST' });
     onUpdate();
  }

  return (
    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
      <div className="flex-1">
        <div className="flex items-center gap-3 mb-2">
          <StatusBadge status={job.status} />
          <h3 className="font-medium text-white truncate">{job.filename}</h3>
        </div>
        <div className="flex flex-wrap gap-4 text-sm text-gray-400">
          <span className="flex items-center gap-1"><Clock size={14} /> {new Date(job.createdAt).toLocaleString()}</span>
          <span>Frames: {job.frameStart}-{job.frameEnd}</span>
          <span>{job.resolution}</span>
          <span>{job.outputFormat.toUpperCase()}</span>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {job.status === 'ready' && (
          <button onClick={handleStart} className="flex items-center gap-2 bg-green-600 hover:bg-green-500 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
            <Play size={16} /> Start Render
          </button>
        )}
        {job.status === 'running' && (
           <button onClick={handleComplete} className="flex items-center gap-2 bg-yellow-600 hover:bg-yellow-500 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
             <Loader2 size={16} className="animate-spin" /> Complete (Demo)
           </button>
        )}
        {job.status === 'completed' && (
          <button onClick={handleDownload} disabled={downloading} className="flex items-center gap-2 bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
            <Download size={16} /> {downloading ? 'Getting Link...' : 'Download'}
          </button>
        )}
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: Job['status'] }) {
  const styles = {
    queued: 'bg-gray-700 text-gray-300',
    ready: 'bg-blue-900/50 text-blue-300 border-blue-800',
    running: 'bg-yellow-900/50 text-yellow-300 border-yellow-800',
    completed: 'bg-green-900/50 text-green-300 border-green-800',
    failed: 'bg-red-900/50 text-red-300 border-red-800',
  };

  const icons = {
    queued: <Clock size={14} />,
    ready: <CheckCircle size={14} />,
    running: <RefreshCw size={14} className="animate-spin" />,
    completed: <CheckCircle size={14} />,
    failed: <XCircle size={14} />,
  };

  return (
    <span className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border border-transparent ${styles[status]}`}>
      {icons[status]}
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}

function CreateJob({ onCreated }: { onCreated: () => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [settings, setSettings] = useState({
    frame_start: 1,
    frame_end: 250,
    resolution: '1080p',
    output_format: 'mp4'
  });

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!file) return;

    setUploading(true);
    try {
      // 1. Create Job
      const res = await client.api.fetch('/api/jobs', {
        method: 'POST',
        body: JSON.stringify({
          filename: file.name,
          ...settings
        })
      });
      const { data: job } = await res.json();

      // 2. Upload File
      const formData = new FormData();
      formData.append('file', file);
      
      await client.api.fetch(`/api/jobs/${job.id}/upload`, {
        method: 'POST',
        body: formData
      });

      onCreated();
    } catch (e) {
      console.error(e);
      alert('Failed to create job');
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className="max-w-2xl mx-auto bg-gray-800 rounded-xl p-8 border border-gray-700">
      <h3 className="text-xl font-bold mb-6">New Render Job</h3>
      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* File Upload */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-gray-300">Blender File (.blend)</label>
          <div className="border-2 border-dashed border-gray-600 rounded-lg p-8 text-center hover:border-blue-500 transition-colors cursor-pointer relative">
            <input 
              type="file" 
              accept=".blend,.zip"
              onChange={e => setFile(e.target.files?.[0] || null)}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <div className="flex flex-col items-center gap-2 text-gray-400">
              <FileUp size={32} />
              {file ? (
                <span className="text-white font-medium">{file.name}</span>
              ) : (
                <span>Drop your .blend file here or click to browse</span>
              )}
            </div>
          </div>
        </div>

        {/* Settings Grid */}
        <div className="grid grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-300">Frame Start</label>
            <input 
              type="number" 
              value={settings.frame_start}
              onChange={e => setSettings({...settings, frame_start: parseInt(e.target.value)})}
              className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-300">Frame End</label>
            <input 
              type="number" 
              value={settings.frame_end}
              onChange={e => setSettings({...settings, frame_end: parseInt(e.target.value)})}
              className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-300">Resolution</label>
            <select 
              value={settings.resolution}
              onChange={e => setSettings({...settings, resolution: e.target.value})}
              className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="720p">720p HD</option>
              <option value="1080p">1080p Full HD</option>
              <option value="4k">4K Ultra HD</option>
            </select>
          </div>
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-300">Output Format</label>
            <select 
              value={settings.output_format}
              onChange={e => setSettings({...settings, output_format: e.target.value})}
              className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="mp4">MP4 Video</option>
              <option value="png">PNG Sequence</option>
            </select>
          </div>
        </div>

        <button 
          type="submit" 
          disabled={!file || uploading}
          className="w-full bg-blue-600 hover:bg-blue-500 disabled:bg-gray-700 disabled:text-gray-500 text-white font-bold py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
        >
          {uploading ? (
            <>
              <Loader2 size={20} className="animate-spin" /> Uploading...
            </>
          ) : (
            'Create Render Job'
          )}
        </button>
      </form>
    </div>
  );
}

export default App;
