# AIDP RenderHub - Project Documentation

**AIDP RenderHub** is a mobile-first React application for managing Blender render jobs, built on the Youware platform.

## Project Status

- **Project Type**: Full-Stack Web Application (React + Hono/Youbase)
- **Entry Point**: `src/main.tsx`
- **Backend**: `backend/src/index.ts` (Hono + Drizzle)
- **Database**: PostgreSQL (Youbase D1)
- **Storage**: Youbase Storage (S3-compatible)

## Core Features Implemented

### 1. Job Management
- **Create Job**: Users can upload `.blend` files and configure render settings (frames, resolution, format).
- **List Jobs**: Dashboard view showing all jobs with real-time status updates.
- **Job Details**: Detailed view of job parameters and progress.

### 2. Backend API (Youbase)
- **Endpoints**:
  - `POST /api/jobs`: Create job record
  - `POST /api/jobs/:id/upload`: Upload file to storage
  - `POST /api/render/start`: Trigger local render worker (New)
  - `GET /api/jobs/:id/download`: Generate secure download URL
- **Database Schema**: `jobs` table with status indexing.
- **Storage**: `uploads` bucket for secure file handling.

### 3. Mobile-First UI
- **Responsive Design**: Optimized for mobile and desktop.
- **Real-time Updates**: Polling mechanism for job status.
- **Secure Auth**: Integrated Youbase authentication.

### 4. Render Worker
- **Location**: `/worker` directory.
- **Type**: Dockerized Python worker (Blender + FFmpeg).
- **Integration**: Triggered via `POST /api/render/start` using local process spawning.
- **Simulation**: Supports simulated rendering if Blender is not installed.

## Mobile Development Guidelines

### Mobile-First Strategy
- **Touch-Optimized**: 44px minimum touch targets.
- **Safe Area**: Layouts respect device notches and safe areas.
- **Performance**: Optimized asset loading and state management.

### Architecture
- **Frontend**: React 18, Tailwind CSS, Lucide Icons.
- **Backend**: Hono serverless functions.
- **State**: Local state + API polling (simple and robust).

## Deployment
- **Backend**: Deployed to Youbase Edge (Staging).
- **Frontend**: Ready for static hosting.

## Future Improvements
- Implement WebSocket for real-time updates instead of polling.
- Add actual Blender rendering worker integration (currently mocked).
- Add payment integration for render credits.
