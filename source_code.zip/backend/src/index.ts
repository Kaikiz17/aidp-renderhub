import { Hono } from "hono";
import type { Client } from "@sdk/server-types";
import { tables, buckets } from "@generated";
import { eq, desc } from "drizzle-orm";

export async function createApp(
  edgespark: Client<typeof tables>
): Promise<Hono> {
  const app = new Hono();

  // List Jobs
  app.get('/api/jobs', async (c) => {
    const jobs = await edgespark.db.select().from(tables.jobs).orderBy(desc(tables.jobs.createdAt));
    return c.json({ data: jobs });
  });

  // Create Job
  app.post('/api/jobs', async (c) => {
    const body = await c.req.json();
    const id = crypto.randomUUID();
    const now = Date.now();
    
    const job = {
      id,
      status: 'queued',
      filename: body.filename,
      frameStart: body.frame_start,
      frameEnd: body.frame_end,
      resolution: body.resolution,
      outputFormat: body.output_format,
      createdAt: now,
      updatedAt: now,
      costEstimate: 'Calculating...',
    };

    await edgespark.db.insert(tables.jobs).values(job);
    return c.json({ data: job });
  });

  // Get Job
  app.get('/api/jobs/:id', async (c) => {
    const id = c.req.param('id');
    const result = await edgespark.db.select().from(tables.jobs).where(eq(tables.jobs.id, id));
    if (result.length === 0) return c.json({ error: 'Not found' }, 404);
    return c.json({ data: result[0] });
  });

  // Upload File
  app.post('/api/jobs/:id/upload', async (c) => {
    const id = c.req.param('id');
    const body = await c.req.parseBody();
    const file = body['file'];

    if (file instanceof File) {
      const path = `jobs/${id}/${file.name}`;
      const buffer = await file.arrayBuffer();
      await edgespark.storage.from(buckets.uploads).put(path, buffer);
      
      await edgespark.db.update(tables.jobs)
        .set({ status: 'ready', updatedAt: Date.now() })
        .where(eq(tables.jobs.id, id));
        
      return c.json({ success: true, path });
    }
    return c.json({ error: 'No file' }, 400);
  });

  // Start Job (Legacy)
  app.post('/api/jobs/:id/start', async (c) => {
    const id = c.req.param('id');
    await edgespark.db.update(tables.jobs)
      .set({ status: 'running', updatedAt: Date.now() })
      .where(eq(tables.jobs.id, id));
    return c.json({ success: true });
  });

  // Start Render Job (Worker Trigger)
  app.post('/api/render/start', async (c) => {
    const body = await c.req.json();
    const jobId = body.jobId;
    
    if (!jobId) return c.json({ error: 'jobId is required' }, 400);

    const jobs = await edgespark.db.select().from(tables.jobs).where(eq(tables.jobs.id, jobId));
    if (jobs.length === 0) return c.json({ error: 'Job not found' }, 404);
    const job = jobs[0];

    // Update status
    await edgespark.db.update(tables.jobs)
      .set({ status: 'running', updatedAt: Date.now(), logs: 'Starting render job...\n' })
      .where(eq(tables.jobs.id, jobId));

    try {
        // Dynamic imports to avoid build errors on edge runtime
        // This will only work in Node.js environment (local dev)
        const { spawn } = await import("node:child_process");
        const fs = await import("node:fs");
        const path = await import("node:path");

        // Prepare paths
        // Assuming we are in backend/ directory or root. Try to find worker.
        let workerScript = path.resolve(process.cwd(), 'worker/worker.py');
        if (!fs.existsSync(workerScript)) {
            workerScript = path.resolve(process.cwd(), '../worker/worker.py');
        }
        
        const tempDir = path.resolve(process.cwd(), 'temp_render');
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
        
        const jobDir = path.join(tempDir, jobId);
        if (!fs.existsSync(jobDir)) fs.mkdirSync(jobDir, { recursive: true });

        // Download file
        const storagePath = `jobs/${jobId}/${job.filename}`;
        const fileContent = await edgespark.storage.from(buckets.uploads).get(storagePath);
        
        let buffer: Buffer;
        if (fileContent instanceof Response) {
            buffer = Buffer.from(await fileContent.arrayBuffer());
        } else if (fileContent instanceof ArrayBuffer) {
            buffer = Buffer.from(fileContent);
        } else {
             // Fallback or error if type is unknown, but try to cast
             buffer = Buffer.from(fileContent as any);
        }
        
        const localFilePath = path.join(jobDir, job.filename);
        fs.writeFileSync(localFilePath, buffer);
        
        // Run worker
        const outputDir = path.join(jobDir, 'output');
        
        const pythonProcess = spawn('python3', [
            workerScript,
            '--blend_file', localFilePath,
            '--frame_start', String(job.frameStart),
            '--frame_end', String(job.frameEnd),
            '--resolution', job.resolution,
            '--output_format', job.outputFormat,
            '--output_dir', outputDir
        ]);

        let logs = 'Starting render job...\n';

        pythonProcess.stdout.on('data', (data: any) => {
            const msg = data.toString();
            console.log(`[Worker ${jobId}] ${msg}`);
            logs += msg;
        });

        pythonProcess.stderr.on('data', (data: any) => {
            const msg = data.toString();
            console.error(`[Worker ${jobId} Error] ${msg}`);
            logs += `ERROR: ${msg}`;
        });

        pythonProcess.on('close', async (code: number) => {
            const status = code === 0 ? 'completed' : 'failed';
            logs += `\nWorker exited with code ${code}`;
            
            await edgespark.db.update(tables.jobs)
                .set({ 
                    status, 
                    updatedAt: Date.now(), 
                    logs 
                })
                .where(eq(tables.jobs.id, jobId));
        });

    } catch (e: any) {
        console.error(e);
        // If import fails (e.g. on Edge), log it
        const errorMsg = e.code === 'ERR_MODULE_NOT_FOUND' 
            ? 'Worker execution not supported in this environment (Node.js required)' 
            : e.message;
            
        await edgespark.db.update(tables.jobs)
            .set({ status: 'failed', logs: `Failed to start: ${errorMsg}` })
            .where(eq(tables.jobs.id, jobId));
        return c.json({ error: errorMsg }, 500);
    }

    return c.json({ success: true, message: 'Render started' });
  });

  // Complete Job (Demo)
  app.post('/api/jobs/:id/complete', async (c) => {
    const id = c.req.param('id');
    await edgespark.db.update(tables.jobs)
      .set({ status: 'completed', updatedAt: Date.now() })
      .where(eq(tables.jobs.id, id));
    return c.json({ success: true });
  });
  
  // Status
  app.get('/api/jobs/:id/status', async (c) => {
    const id = c.req.param('id');
    const result = await edgespark.db.select({ status: tables.jobs.status }).from(tables.jobs).where(eq(tables.jobs.id, id));
    if (result.length === 0) return c.json({ error: 'Not found' }, 404);
    return c.json({ data: result[0] });
  });

  // Download
  app.get('/api/jobs/:id/download', async (c) => {
    const id = c.req.param('id');
    const job = (await edgespark.db.select().from(tables.jobs).where(eq(tables.jobs.id, id)))[0];
    if (!job) return c.json({ error: 'Not found' }, 404);
    
    // Mock output path
    const path = `jobs/${id}/output.${job.outputFormat}`;
    const { downloadUrl } = await edgespark.storage.from(buckets.uploads).createPresignedGetUrl(path, 3600);
    
    return c.json({ data: { url: downloadUrl } });
  });

  return app;
}
