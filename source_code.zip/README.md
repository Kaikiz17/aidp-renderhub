# AIDP RenderHub

A full-stack web application for managing Blender render jobs. Users can upload `.blend` files, configure render settings, and track job progress.

## Features

- **Job Management**: Create, list, and track render jobs.
- **File Upload**: Upload `.blend` files and assets (zip).
- **Render Settings**: Configure frame range, resolution, and output format.
- **Status Tracking**: Real-time status updates (Queued, Running, Completed, Failed).
- **Download**: Secure download links for rendered outputs.
- **Authentication**: Secure user authentication via Youbase.

## Tech Stack

- **Frontend**: React, Tailwind CSS, Lucide Icons
- **Backend**: Hono (Edge Compatible), Drizzle ORM
- **Database**: PostgreSQL (via Youbase D1)
- **Storage**: S3-compatible Object Storage (via Youbase)

## Setup

1. **Install Dependencies**
   ```bash
   npm install
   cd backend && npm install
   ```

2. **Environment Setup**
   Copy `.env.example` to `.env` (if running locally against a specific backend, though `client.ts` is pre-configured).

3. **Run Development**
   ```bash
   # Frontend
   npm run dev

   # Backend (Staging)
   cd backend && npx edgespark dev
   ```

## API Endpoints

- `GET /api/jobs` - List all jobs
- `POST /api/jobs` - Create a new job
- `GET /api/jobs/:id` - Get job details
- `POST /api/jobs/:id/upload` - Upload file
- `POST /api/jobs/:id/start` - Start rendering
- `GET /api/jobs/:id/status` - Check status
- `GET /api/jobs/:id/download` - Get download URL

## Deployment

The backend is deployed to Youbase Edge. The frontend can be deployed to any static host (Vercel, Netlify, etc.).
