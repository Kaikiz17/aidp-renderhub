import { createEdgeSpark } from "@edgespark/client";
import "@edgespark/client/styles.css";

export const client = createEdgeSpark({
  baseUrl: "https://staging--glp0et5vykstr4ddwm75.youbase.cloud"
});
