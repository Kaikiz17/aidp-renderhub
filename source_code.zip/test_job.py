import requests
import time
import sys
import os

BASE_URL = "http://localhost:8787" # Adjust if needed

def create_job():
    print("Creating job...")
    payload = {
        "filename": "test.blend",
        "frame_start": 1,
        "frame_end": 5,
        "resolution": "720p",
        "output_format": "mp4"
    }
    try:
        res = requests.post(f"{BASE_URL}/api/jobs", json=payload)
        res.raise_for_status()
        job = res.json()['data']
        print(f"Job created: {job['id']}")
        return job['id']
    except Exception as e:
        print(f"Failed to create job: {e}")
        sys.exit(1)

def upload_file(job_id):
    print(f"Uploading file for job {job_id}...")
    # Create a dummy blend file
    with open("test.blend", "wb") as f:
        f.write(b"DUMMY BLEND FILE CONTENT")
    
    files = {'file': ('test.blend', open('test.blend', 'rb'))}
    try:
        res = requests.post(f"{BASE_URL}/api/jobs/{job_id}/upload", files=files)
        res.raise_for_status()
        print("Upload successful")
    except Exception as e:
        print(f"Failed to upload file: {e}")
        sys.exit(1)
    finally:
        if os.path.exists("test.blend"):
            os.remove("test.blend")

def start_render(job_id):
    print(f"Starting render for job {job_id}...")
    payload = {"jobId": job_id}
    try:
        res = requests.post(f"{BASE_URL}/api/render/start", json=payload)
        res.raise_for_status()
        print("Render started")
    except Exception as e:
        print(f"Failed to start render: {e}")
        # Continue to check status anyway, maybe it failed async

def check_status(job_id):
    print(f"Checking status for job {job_id}...")
    for _ in range(10):
        try:
            res = requests.get(f"{BASE_URL}/api/jobs/{job_id}")
            res.raise_for_status()
            job = res.json()['data']
            print(f"Status: {job['status']}")
            if job.get('logs'):
                print(f"Logs: {job['logs']}")
            
            if job['status'] in ['completed', 'failed']:
                return
            
            time.sleep(2)
        except Exception as e:
            print(f"Failed to check status: {e}")
            time.sleep(2)

if __name__ == "__main__":
    job_id = create_job()
    upload_file(job_id)
    start_render(job_id)
    check_status(job_id)
